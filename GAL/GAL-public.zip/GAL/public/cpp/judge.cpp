#include "judge.h"
#include <cstdio>
using namespace std;
const int SIZE = 100;
int PRINT_SIZE = 100;
int RAND_SIZE = 100;
int MAGIC = 1;

const int MOD = 1000000097;

enum Type { Produkcja, Handel, Przetwarzanie, Ataki, Podatki };
enum Print { None, Hash, Full };

long long outputArray[SIZE][SIZE];
char command[100];
igalaxy* program = 0;

long seed = 0;
int _rand() {
  seed = seed * 134775813 + 1;
  return (int)((seed & 0x7FFFFFFF) % 100000007);
}

void testSummary(Print print) {
  int hash = 0;
  outputArray[_rand() % SIZE][_rand() % SIZE] = 123;
  if (program) program->summary(outputArray);
  for (int i = 0; i < PRINT_SIZE; i++) {
    for (int j = 0; j < PRINT_SIZE; j++) {
      long long x = outputArray[i][j];
      if (print == Full) printf("%03d ", x % 1000);
      hash *= 13;
      hash += (int)(outputArray[i][j] % MOD);
    }
    if (print == Full) printf("\n");
  }
  if (print != None) printf("%d\n", hash * MAGIC);
  if (print == Full) printf("\n");
}

void judge::run(igalaxy* solution) {
    program = solution;
    int mode;
    scanf("%d", &mode);

    int n, type;
    int a, b, c, d, e, f, g, h;
    PRINT_SIZE = 10;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
      scanf("%d", &type);
      if (type == 0) {
        testSummary(Full);
        continue;
      }
      scanf("%s", command);
      solution->report(command);
      printf("%s\n", command);
    }
}
