#include "judge.h"

class galaxy : public igalaxy {
public:
	void report(char* text) {}
	void summary(long long int output[100][100]) {}
};

galaxy solution;
int main() {
	judge::run(&solution);
	return 0;
}
