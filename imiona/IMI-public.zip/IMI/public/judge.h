#pragma warning(disable : 4996)


class Judge
{
public:
	static int getPopulation();
	static void getCitizenName(int id, char *name);
	static int getQueryCount();
	static void getCitizenLogin(char *login);
	static void replyCitizenName(char *name);
};

