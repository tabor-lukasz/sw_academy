class IKLO {
public:
	virtual int maxTowerHeight(int n, int *a, int *b, int *c) = 0;
};

class Judge
{
public:
	static void run(IKLO *solution);
};

