public class KLO {

	public int maxTowerHeight(int n, int[] a, int[] b, int[] c) {
		return 0;
	}

	public static void main(String[] args) {
		Judge.run(new KLO());
	}
}
