#include "judge.h"

class KLO : public IKLO {
public:
	int maxTowerHeight(int n, int *a, int *b, int *c) {
		return 0;
	}
};


KLO sol;
int main() {
	Judge::run(&sol);
	return 0;
}
